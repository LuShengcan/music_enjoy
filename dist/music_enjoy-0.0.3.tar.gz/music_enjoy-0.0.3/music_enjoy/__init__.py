from get_page import *
__all__ = ['get_page']
