from . import *
__all__ = ['get_page']
